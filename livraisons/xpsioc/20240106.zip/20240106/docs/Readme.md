# Saphir documentation

This document is an entry point to the documentation of Saphir, the robust sheep-dip solution.

## Structure

The documentation is structured into subject-specific documents.

### Development

- The documentation for the development of Saphir is available [here](developing-saphir.md).
- The documentation of PSEC is available [here (#TODO)](#), including the documentation for [preparing the development environment](#).

### Performance

### Deployment

- Create deployment infrastructure
- 