# Arborescence des disques

## Dom0

| Chemin | Type | Contenu |
|---|---|---|
| `/etc/panoptiscan/xen` | Dossier | Contient les fichiers de configuration de Xen pour Panoptiscan |
| `/etc/panoptiscan/usb-conf` | Fichier | Définit la variable `USB_SLOTS` contenant la liste des slots USB à affecter à la VM sys-usb |

