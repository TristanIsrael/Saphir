#!/bin/sh

cd /usr/lib/saphir/gui/src/Saphir/
DISPLAY=:0 /usr/bin/python3 main.py -platform xcb 
