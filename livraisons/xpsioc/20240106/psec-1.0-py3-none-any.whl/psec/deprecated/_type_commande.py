class TypeCommande:
    LIST_DISKS = "list_disks"
    LIST_FILES = "list_files"
    READ_FILE = "read_file"
    COPY_FILE = "copy_file"
    REMOVE_FILE = "remove_file"
    START_BENCHMARK = "start_benchmark"
    GET_FILE_FOOTPRINT = "get_file_footprint"
    CREATE_FILE = "create_file"
    